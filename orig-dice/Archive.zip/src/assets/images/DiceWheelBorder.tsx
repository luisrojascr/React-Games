import React from 'react'

import styled from 'styled-components'

export default function DiceWheelBorder(props: any): JSX.Element {
  return (
    <Wrapper
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 497 497"
    >
      <defs>
        <path id="prefix__a" d="M0 0.122L19.908 0.122 19.908 0.698 0 0.698z" />
        <path
          id="prefix__b"
          d="M0.335 0.137L0.791 0.137 0.791 20.873 0.335 20.873z"
        />
      </defs>
      <g fill="none" fillRule="evenodd">
        <g>
          <g
            stroke="#334284"
            strokeLinecap="round"
            strokeLinejoin="bevel"
            strokeWidth="2.304"
          >
            <path
              d="M14.412.244L14.412 20.882M.093.694L1.389 21.292"
              transform="translate(2 2) translate(18.437 17.525) translate(213.628 .218)"
            />
          </g>
          <path
            stroke="#334284"
            strokeLinecap="round"
            strokeLinejoin="bevel"
            strokeWidth="2.304"
            d="M199.46 2.261L201.326 22.851M185.31 4.503L188.456 24.891M171.329 7.63L175.74 27.734M157.572 11.629L163.227 31.372M144.093 16.485L150.968 35.788M130.946 22.177L139.009 40.966M118.181 28.685L127.399 46.885M105.85 35.981L116.184 53.521M94.002 44.038L105.407 60.849M82.682 52.824L95.111 68.84M71.936 62.303L85.337 77.462M61.806 72.438L76.123 86.681M52.332 83.19L67.506 96.46M35.5 106.372L52.196 117.545M28.207 118.709L45.564 128.766M21.703 131.481L39.648 140.383M16.014 144.636L34.473 152.348M7.164 171.887L26.424 177.134M4.039 185.876L23.582 189.857"
            transform="translate(2 2) translate(18.437 17.525)"
          />
          <g>
            <path
              stroke="#334284"
              strokeLinecap="round"
              strokeLinejoin="bevel"
              strokeWidth="2.304"
              d="M1.798.379L21.543 3.08M.45 14.649L20.317 16.059"
              transform="translate(2 2) translate(18.437 17.525) translate(0 199.655)"
            />
            <g transform="translate(2 2) translate(18.437 17.525) translate(0 199.655) translate(0 28.623)" />
            <path
              stroke="#334284"
              strokeLinecap="round"
              strokeLinejoin="bevel"
              strokeWidth="2.304"
              d="M.45 43.417L20.317 42.006M1.798 57.687L21.543 54.986"
              transform="translate(2 2) translate(18.437 17.525) translate(0 199.655)"
            />
          </g>
          <path
            stroke="#334284"
            strokeLinecap="round"
            strokeLinejoin="bevel"
            strokeWidth="2.304"
            d="M4.039 271.5L23.582 267.518M7.164 285.488L26.424 280.241M16.014 312.739L34.473 305.027M21.703 325.894L39.648 316.993M28.207 338.666L45.564 328.609M35.5 351.004L52.196 339.831M52.332 374.185L67.506 360.915M61.806 384.937L76.123 370.695M71.936 395.073L85.337 379.914M82.682 404.552L95.111 388.536M105.85 421.394L116.184 403.854M118.181 428.691L127.399 410.491M130.946 435.198L139.009 416.41M144.093 440.891L150.968 421.588M171.329 449.745L175.74 429.641M185.31 452.872L188.456 432.485"
            transform="translate(2 2) translate(18.437 17.525)"
          />
          <g>
            <path
              stroke="#334284"
              strokeLinecap="round"
              strokeLinejoin="bevel"
              strokeWidth="2.304"
              d="M.133 20.921L2.686.348M14.217 22.276L15.496 1.581"
              transform="translate(2 2) translate(18.437 17.525) translate(199.325 434.178)"
            />
            <g transform="translate(2 2) translate(18.437 17.525) translate(199.325 434.178) translate(27.794 1.855)">
              <mask id="prefix__c" fill="#fff" />
              <path
                stroke="#334284"
                strokeLinecap="round"
                strokeLinejoin="bevel"
                strokeWidth="2.304"
                d="M0.563 20.873L0.563 0.137"
                mask="url(#prefix__c)"
              />
            </g>
            <path
              stroke="#334284"
              strokeLinecap="round"
              strokeLinejoin="bevel"
              strokeWidth="2.304"
              d="M42.497 22.276L41.218 1.581M56.582 20.921L54.029.348"
              transform="translate(2 2) translate(18.437 17.525) translate(199.325 434.178)"
            />
          </g>
          <path
            stroke="#334284"
            strokeLinecap="round"
            strokeLinejoin="bevel"
            strokeWidth="2.304"
            d="M270.052 452.872L266.906 432.485M284.033 449.745L279.623 429.641M311.269 440.891L304.395 421.588M324.417 435.198L316.353 416.41M337.181 428.691L327.963 410.491M349.512 421.394L339.179 403.854M372.68 404.552L360.251 388.536M383.426 395.073L370.025 379.914M393.556 384.937L379.239 370.695M403.03 374.185L387.856 360.915M419.863 351.004L403.166 339.831M427.156 338.666L409.799 328.609M433.659 325.894L415.715 316.993M439.349 312.739L420.89 305.027M448.198 285.488L428.938 280.241M451.323 271.5L431.781 267.518M453.564 257.342L433.819 254.641"
            transform="translate(2 2) translate(18.437 17.525)"
          />
          <g
            stroke="#334284"
            strokeLinecap="round"
            strokeLinejoin="bevel"
            strokeWidth="2.304"
          >
            <path
              d="M20.273 29.105L.406 27.695M20.273.337L.406 1.748"
              transform="translate(2 2) translate(18.437 17.525) translate(434.64 213.966)"
            />
          </g>
          <path
            stroke="#334284"
            strokeLinecap="round"
            strokeLinejoin="bevel"
            strokeWidth="2.304"
            d="M453.564 200.033L433.819 202.735M451.323 185.876L431.781 189.857M448.198 171.887L428.938 177.134M439.349 144.636L420.89 152.348M433.659 131.481L415.715 140.383M427.156 118.709L409.799 128.766M419.863 106.372L403.166 117.545M403.03 83.19L387.856 96.46M393.556 72.438L379.239 86.681M383.426 62.303L370.025 77.462M372.68 52.824L360.251 68.84M349.512 35.981L339.179 53.521M337.181 28.685L327.963 46.885M324.417 22.177L316.353 40.966M311.269 16.485L304.395 35.788M284.033 7.63L279.623 27.734M270.052 4.503L266.906 24.891M255.903 2.261L254.037 22.851M241.64.912L241.064 21.624"
            transform="translate(2 2) translate(18.437 17.525)"
          />
        </g>
        <g
          stroke="#334284"
          strokeLinecap="round"
          strokeLinejoin="bevel"
          strokeWidth="2.304"
        >
          <path
            d="M170.336 12.072L182.647 49.983M101.616 47.106L125.033 79.356M47.08 101.673L79.311 125.104M12.065 170.431L49.956 182.75M12.065 322.87L49.956 310.551M47.08 391.628L79.311 368.198M101.616 446.195L125.033 413.946M170.336 481.229L182.647 443.318"
            transform="translate(2 2)"
          />
          <path
            d="M0.535 39.958L0.535 0.095"
            transform="translate(2 2) translate(246.1 453.344)"
          />
          <path
            d="M246.512 0L246.512 39.863M0 246.651L39.84 246.651M322.688 481.229L310.377 443.318M391.408 446.195L367.99 413.946M445.944 391.628L413.713 368.198M480.958 322.87L443.068 310.551M493.024 246.651L453.183 246.651M480.958 170.431L443.068 182.75M445.944 101.673L413.713 125.104M391.408 47.106L367.99 79.356M322.688 12.072L310.377 49.983"
            transform="translate(2 2)"
          />
        </g>
        <g transform="translate(2 2) translate(28.8 28.8)">
          <circle cx="218.4" cy="218.4" r="218.4" fill="#334284" />
          <circle cx="218.4" cy="218.4" r="187.2" fill="#111A41" />
        </g>
      </g>
    </Wrapper>
  )
}

const Wrapper = styled.svg`
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  right: 0px;
  width: 100%;
  height: 100%;
  strokewidth: 0;
  overflow: hidden;
  fill: currentColor;
`
