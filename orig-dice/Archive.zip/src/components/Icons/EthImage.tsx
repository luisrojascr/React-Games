import React from 'react'

const EthImage = (props: any) => (
  <svg
    width={props.width}
    height={props.height}
    viewBox="0 0 18 19"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <circle cx="9" cy="9.5" r="9" fill="#627EEA" />
    <circle cx="8.99999" cy="9.5" r="4.95" fill="#627EEA" />
    <path
      d="M8.84467 5.78751V8.53166L11.164 9.56807L8.84467 5.78751Z"
      fill="white"
      fillOpacity="0.602"
    />
    <path
      d="M8.84466 5.78751L6.52496 9.56807L8.84466 8.53166V5.78751Z"
      fill="white"
    />
    <path
      d="M8.84467 11.3467V13.2113L11.1656 10.0003L8.84467 11.3467Z"
      fill="white"
      fillOpacity="0.602"
    />
    <path
      d="M8.84466 13.2113V11.3464L6.52496 10.0003L8.84466 13.2113Z"
      fill="white"
    />
    <path
      d="M8.84467 10.9145L11.164 9.56779L8.84467 8.532V10.9145Z"
      fill="white"
      fillOpacity="0.2"
    />
    <path
      d="M6.52496 9.56779L8.84466 10.9145V8.532L6.52496 9.56779Z"
      fill="white"
      fillOpacity="0.602"
    />
  </svg>
)
export default EthImage
