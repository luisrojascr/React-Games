import React from 'react'

const DashIcon = (props: any) => (
  <svg
    {...props}
    xmlns="http://www.w3.org/2000/svg"
    height={props.height}
    viewBox="0 0 256 256"
    width={props.width}
  >
    <defs />
    <g data-name="dash dashcoin" id="dash_dashcoin">
      <g data-name="dash dash" id="dash_dash">
        <circle
          fill="#0388e5"
          cx="128"
          cy="128"
          data-name="Эллипс 7"
          id="Эллипс_7"
          r="128"
        />
        <path
          fill="#fff"
          fillRule="evenodd"
          d="M522.9,712l-7.136,21.412h87.421s10.7-1.9,7.136,8.921-11.708,33.233-12.489,35.687-2.676,3.568-7.136,3.568H499.7L490.784,803H604.966c3.568,0,16.168-.223,23.193-19.628S646.775,732.082,646,724.49c-0.558-5.464-1.45-12.49-17.841-12.49H522.9Zm28.546,35.686-7.136,19.628H489l7.136-19.628h55.307Z"
          data-name="Фигура 1"
          id="Фигура_1"
          transform="translate(-440 -629)"
        />
      </g>
    </g>
  </svg>
)
export default DashIcon
